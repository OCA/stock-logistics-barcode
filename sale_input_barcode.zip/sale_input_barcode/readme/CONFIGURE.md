No specific configuration necessary
